
import React, { Component } from 'react';
import PropTypes from 'prop-types';

class PersonalInfoForm extends Component {
	constructor(props) {
	    super(props);
	}


	render() {
		return (
			<div>
				<span> dadasda </span>
			</div>
		);
	}
}

export default PersonalInfoForm;