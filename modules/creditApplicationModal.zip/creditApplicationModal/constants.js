export const NODE_TO_MOUNT = 'creditApplicationModal';
export const DATA_COMP_ID = 'data-compid';
