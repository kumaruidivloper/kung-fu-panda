import { isValidZipCode, isValidCity, isValidAddress, isValidName, isValidPhoneNumber } from './../../utils/validationRules';

/**
 *
 * @param {Object} values - It gets the values from redux form and returns the validation message according to value entered.
 *
 */
// TODO - Replace all hardcoded error messages with CMS labels
export const validate = (values, props) => {
  const errors = {};
  const { cms } = props;
  if (values.firstName && !isValidName(values.firstName)) {
    errors.firstName = "FirstName is not valid";
  } else if (!values.firstName) {
    errors.firstName = "First Name is required";
  }
  if (values.lastName && !isValidName(values.lastName)) {
    errors.lastName = "LastName is not valid";
  } else if (!values.lastName) {
    errors.lastName = "Last Name is required";
  }
  if (values.zipcode && !isValidZipCode(values.zipcode)) {
    errors.zipcode = "Zipcode is not proper";
  } else if (!values.zipCode) {
    errors.zipcode = "zipcode is required";
  }
  if (values.phoneNumber && !isValidPhoneNumber(values.phoneNumber)) {
    errors.phoneNumber = "Phone number is not proper";
  } else if (!values.phoneNumber) {
    errors.phoneNumber = "Phone number is required";
  }
  if (values.city && !isValidCity(values.city)) {
    errors.city = "city is not proper";
  } else if (!values.city) {
    errors.city = 'Required';
  }
  if (!values.state) {
    errors.state = 'Required';
  }
  if (!values.agreeTermsAndConditions) {
    errors.agreeTermsAndConditions = '';
  }

    return errors;
};

export default validate;
