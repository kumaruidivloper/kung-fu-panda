/**
 * shippingAddressForm.component.js renders the form for shipping Address and maintains state
 * of the form with respect to city,state,zipcode and other fields with their related logic.
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Field, reduxForm, getFormValues, change as changeFieldValue } from 'redux-form';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import RenderTextField from './Components/renderInputField/renderInputFieldComponent';


export class creditApplicationStep1 extends React.PureComponent {
  constructor(props) {
    super(props);
  
    this.handleKeyDown = this.handleKeyDown.bind(this);
    this.handleKeyUp = this.handleKeyUp.bind(this);
  }


  /**
   * Method for handling keyup and resetting the value if it exceeds the maxLength.
   * @param {object} e Event object corresponding to key down.
   */
  handleKeyUp = e => {
    if (e.target && e.target.maxLength && e.target.value.length >= e.target.maxLength) {
      e.target.value = e.target.value.substring(0, e.target.maxLength); // Resetting the value for Andriod devices
      return false;
    }
    return null;
  };

  /**
   * Method for handling key presses. Submits the form on an any of the field trigger submit event.
   * @param {object} e Event object corresponding to key down.
   */
  handleKeyDown = e => {
    if (e.key === 'Enter' && e.shiftKey === false) {
      e.preventDefault();
      const { handleSubmit, onSubmitForm } = this.props;
      handleSubmit(data => onSubmitForm(data))();
    }
  };

  render() {
    const { handleSubmit } = this.props;
    return (
      <form onSubmit={handleSubmit} name="creditApplicationModal">
        <div className="form">
          <div className="d-flex flex-column flex-md-row justify-content-between">
            <div className="form-group pr-md-1 col-md-6 px-0 col-12  ">
              <Field
                data-auid="checkout_shipping_address_first_name"
                name="firstName"
                id="shipping-address-firstName"
                type="text"
                label="FirstName"
                margin="mb-2"
                touchedMargin="mb-1"
                component={RenderTextField}
                maxLength="50"
                onKeyDown={this.handleKeyDown}
                onKeyUp={this.handleKeyUp}
              />
            </div>
          </div>
        </div>
      </form>
    );
  }
}

creditApplicationStep1.propTypes = {
  handleSubmit: PropTypes.func,
  onSubmitForm: PropTypes.func
};

const mapStateToProps = (reduxState, ownProps) => {
  const { initialVals } = ownProps;
  const existingValues = getFormValues('creditApplicationModal')(reduxState);
  let initialVal = Object.assign({}, initialVals, existingValues);
  return {
    initialValues: initialVal
  };
};

const mapDispatchToProps = dispatch => bindActionCreators({ changeFieldValue }, dispatch);

const creditApplicationStep1Container = reduxForm({
  form: 'creditApplicationModal'
})(creditApplicationStep1);

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(creditApplicationStep1Container);
